"""
Modaics Backend
FastAPI server with FindThisFit CLIP search integration
"""

__version__ = "1.0.0"
